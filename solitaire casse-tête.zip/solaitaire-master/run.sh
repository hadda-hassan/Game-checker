export FLASK_APP=src
export FLASK_DEBUG=1
flask run